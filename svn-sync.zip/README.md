1、插件安装：
在你的Obsidian库目录下创建插件文件夹:<你的库路径>/.obsidian/plugins/svn-sync/，最后把svn-sync.zip里的文件main.js、manifest.json、styles.css解压到 svn-sync 文件夹内。

2、obsidian 启动插件：
![](C:/Users/HONOR/AppData/Roaming/marktext/images/2026-09-29-08-28-02-image.png)

---

# SVN Sync Plugin

1. Plugin installation:
   Create a plugin folder under your Obsidian vault directory: `<your-vault-path>/.obsidian/plugins/svn-sync/`, then extract the files `main.js`, `manifest.json`, and `styles.css` from `svn-sync.zip` into the `svn-sync` folder.

2. Enable the plugin in Obsidian:
   Open *Settings → Community plugins*, turn off *Restricted Mode* if needed, find **SVN Sync** in the list, and toggle it on.
   ![](C:/Users/HONOR/AppData/Roaming/marktext/images/2026-09-29-08-28-02-image.png)
