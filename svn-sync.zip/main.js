var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// main.ts
var main_exports = {};
__export(main_exports, {
  default: () => SvnSyncPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");
var import_child_process = require("child_process");
var import_fs = require("fs");
var nodePath = __toESM(require("path"));
var DEFAULTS = {
  engine: "tortoise",
  svnPath: "svn",
  tortoisePath: "",
  logLimit: 100,
  closeOnEnd: 0,
  keepDialog: true
};
var TORTOISE_CANDIDATES = [
  "C:\\Program Files\\TortoiseSVN\\bin\\TortoiseProc.exe",
  "C:\\Program Files (x86)\\TortoiseSVN\\bin\\TortoiseProc.exe"
];
var SvnSyncPlugin = class extends import_obsidian.Plugin {
  constructor() {
    super(...arguments);
    this.submenuProbe = null;
  }
  async onload() {
    var _a;
    await this.loadSettings();
    if (this.settings.engine === "tortoise" && !this.settings.tortoisePath) {
      this.settings.tortoisePath = (_a = TORTOISE_CANDIDATES.find(import_fs.existsSync)) != null ? _a : "";
      await this.saveSettings();
    }
    this.addCommand({
      id: "svn-update",
      name: "SVN: \u66F4\u65B0 (update)",
      callback: () => this.update()
    });
    this.addCommand({
      id: "svn-add",
      name: "SVN: \u6DFB\u52A0\u5F53\u524D\u6587\u4EF6",
      callback: () => this.addCurrent()
    });
    this.addCommand({
      id: "svn-delete",
      name: "SVN: \u5220\u9664\u5F53\u524D\u6587\u4EF6",
      callback: () => this.deleteCurrent()
    });
    this.addCommand({
      id: "svn-log",
      name: "SVN: \u67E5\u770B\u65E5\u5FD7",
      callback: () => this.showLog()
    });
    this.addCommand({
      id: "svn-commit",
      name: "SVN: \u63D0\u4EA4",
      callback: () => this.requestCommit()
    });
    this.addCommand({
      id: "svn-status",
      name: "SVN: \u67E5\u770B\u72B6\u6001 (status)",
      callback: () => this.showStatus()
    });
    this.addCommand({
      id: "svn-diff",
      name: "SVN: \u5BF9\u6BD4\u5DEE\u5F02 (diff)",
      callback: () => this.diff()
    });
    this.addCommand({
      id: "svn-lock",
      name: "SVN: \u9501\u5B9A (lock)",
      callback: () => this.lock()
    });
    this.addCommand({
      id: "svn-unlock",
      name: "SVN: \u89E3\u9501 (unlock)",
      callback: () => this.unlock()
    });
    this.addCommand({
      id: "svn-unadd",
      name: "SVN: \u53D6\u6D88\u6DFB\u52A0 (unadd)",
      callback: () => this.unadd()
    });
    this.addCommand({
      id: "svn-cleanup",
      name: "SVN: \u6E05\u7406 (cleanup)",
      callback: () => this.cleanup()
    });
    this.addRibbonIcon("cloud-download", "SVN \u66F4\u65B0", () => this.update());
    this.registerFileMenu();
    this.addSettingTab(new SvnSettingTab(this.app, this));
  }
  onunload() {
  }
  // ---------- 右键菜单 ----------
  registerFileMenu() {
    this.registerEvent(
      this.app.workspace.on("file-menu", (menu, file) => {
        const items = [
          ["\u66F4\u65B0 (update)", () => this.update(file.path)],
          ["\u6DFB\u52A0 (add)", () => this.addCurrent(file.path)],
          ["\u53D6\u6D88\u6DFB\u52A0 (unadd)", () => this.unadd(file.path)],
          ["\u5220\u9664 (remove)", () => this.deleteCurrent(file.path)],
          ["\u67E5\u770B\u65E5\u5FD7 (log)", () => this.showLog(file.path)],
          ["\u5BF9\u6BD4\u5DEE\u5F02 (diff)", () => this.diff(file.path)],
          ["\u9501\u5B9A (lock)", () => this.lock(file.path)],
          ["\u89E3\u9501 (unlock)", () => this.unlock(file.path)],
          ["\u6E05\u7406 (cleanup)", () => this.cleanup(file.path)],
          ["\u63D0\u4EA4 (commit)", () => this.requestCommit(file.path)]
        ];
        if (file instanceof import_obsidian.TFolder) {
          items.push(["\u67E5\u770B\u72B6\u6001 (status)", () => this.showStatus(file.path)]);
        }
        const fill = (host) => {
          for (const [title, fn] of items) {
            host.addItem(
              (item) => item.setTitle("SVN: " + title).setIcon("cloud-download").onClick(fn)
            );
          }
        };
        if (this.submenuSupported()) {
          menu.addItem((item) => {
            item.setTitle("SVN\u7BA1\u7406").setIcon("cloud-download");
            fill(item.setSubmenu());
          });
        } else {
          fill(menu);
        }
      })
    );
  }
  submenuSupported() {
    if (this.submenuProbe !== null)
      return this.submenuProbe;
    let ok = false;
    try {
      const probe = new import_obsidian.Menu();
      probe.addItem((it) => {
        ok = typeof it.setSubmenu === "function";
      });
    } catch (e) {
      ok = false;
    }
    this.submenuProbe = ok;
    return ok;
  }
  // ---------- 通用 ----------
  cwd() {
    const adapter = this.app.vault.adapter;
    return typeof adapter.getBasePath === "function" ? adapter.getBasePath() : "";
  }
  abs(p) {
    const base = this.cwd();
    if (!p)
      return base;
    try {
      return nodePath.isAbsolute(p) ? p : nodePath.join(base, p);
    } catch (e) {
      return p;
    }
  }
  useTortoise() {
    return this.settings.engine === "tortoise";
  }
  tortoiseExe() {
    var _a;
    if (this.settings.tortoisePath)
      return this.settings.tortoisePath;
    return (_a = TORTOISE_CANDIDATES.find(import_fs.existsSync)) != null ? _a : TORTOISE_CANDIDATES[0];
  }
  // ---------- TortoiseProc GUI 引擎 ----------
  gui(command, target, extra = []) {
    const exe = this.tortoiseExe();
    const args = [`/command:${command}`, `/path:${target}`, ...extra];
    return new Promise((resolve) => {
      const child = (0, import_child_process.spawn)(exe, args, {
        cwd: this.cwd() || void 0,
        stdio: "ignore",
        windowsHide: false
      });
      child.once("spawn", () => {
        new import_obsidian.Notice(`TortoiseSVN: ${command} \u5DF2\u542F\u52A8`);
        resolve();
      });
      child.once("error", (e) => {
        new import_obsidian.Notice(
          `\u542F\u52A8\u5931\u8D25: ${exe}
${e.message}
\u8BF7\u5728\u63D2\u4EF6\u8BBE\u7F6E\u4E2D\u6307\u5B9A TortoiseProc.exe \u8DEF\u5F84`
        );
        resolve();
      });
    });
  }
  // ---------- svn 命令行引擎 ----------
  svn(args) {
    return new Promise((resolve, reject) => {
      (0, import_child_process.execFile)(
        this.settings.svnPath,
        args,
        {
          cwd: this.cwd(),
          windowsHide: true,
          maxBuffer: 10 * 1024 * 1024,
          encoding: "utf8"
        },
        (err, stdout, stderr) => {
          if (err)
            reject(new Error(stderr || err.message));
          else
            resolve(stdout);
        }
      );
    });
  }
  async try(args, okMsg, quiet) {
    try {
      const out = await this.svn(args);
      if (okMsg)
        new import_obsidian.Notice(okMsg);
      return out;
    } catch (e) {
      if (!quiet)
        new import_obsidian.Notice("SVN \u5931\u8D25: " + String(e.message || e).trim());
      return null;
    }
  }
  activePath() {
    const f = this.app.workspace.getActiveFile();
    return f ? f.path : null;
  }
  // ---------- 业务操作 ----------
  async update(target) {
    const abs = this.abs(target);
    if (this.useTortoise()) {
      await this.gui("update", abs, [`/closeonend:${this.settings.closeOnEnd}`]);
      return;
    }
    new import_obsidian.Notice("SVN \u66F4\u65B0\u4E2D...");
    await this.try(["update", abs], "SVN \u66F4\u65B0\u5B8C\u6210");
  }
  async addCurrent(pathArg) {
    const p = pathArg != null ? pathArg : this.activePath();
    if (!p)
      return new import_obsidian.Notice("\u6CA1\u6709\u76EE\u6807\u6587\u4EF6");
    const abs = this.abs(p);
    if (this.useTortoise())
      return this.gui("add", abs);
    await this.try(["add", "--force", abs], `\u5DF2\u6DFB\u52A0: ${p}`);
  }
  async unadd(pathArg) {
    const p = pathArg != null ? pathArg : this.activePath();
    if (!p)
      return new import_obsidian.Notice("\u6CA1\u6709\u76EE\u6807\u6587\u4EF6");
    const abs = this.abs(p);
    if (this.useTortoise())
      return this.gui("revert", abs);
    const st = await this.try(["status", abs], void 0, true);
    if (st === null)
      return new import_obsidian.Notice("SVN \u72B6\u6001\u83B7\u53D6\u5931\u8D25\uFF0C\u65E0\u6CD5\u53D6\u6D88\u6DFB\u52A0");
    const base = this.cwd();
    const added = st.split(/\r?\n/).filter((l) => l.charAt(0) === "A");
    if (!added.length)
      return new import_obsidian.Notice("\u6CA1\u6709\u5F85\u53D6\u6D88\u7684\u6DFB\u52A0");
    let ok = 0;
    for (const line of added) {
      const m = line.match(/^\S+\s+(.*)$/);
      const t = m ? m[1].trim() : "";
      const target = !t ? abs : nodePath.isAbsolute(t) ? t : nodePath.join(base, t);
      if (await this.try(["revert", target], void 0, true) !== null)
        ok++;
    }
    if (ok)
      new import_obsidian.Notice(`\u5DF2\u53D6\u6D88\u6DFB\u52A0 ${ok} \u9879`);
    else
      new import_obsidian.Notice("\u53D6\u6D88\u6DFB\u52A0\u5931\u8D25");
  }
  async deleteCurrent(pathArg) {
    const p = pathArg != null ? pathArg : this.activePath();
    if (!p)
      return new import_obsidian.Notice("\u6CA1\u6709\u76EE\u6807\u6587\u4EF6");
    const abs = this.abs(p);
    if (this.useTortoise())
      return this.gui("remove", abs);
    const out = await this.try(["delete", "--force", abs]);
    if (out !== null)
      return new import_obsidian.Notice(`\u5DF2\u5220\u9664(\u5F85\u63D0\u4EA4): ${p}`);
    const f = this.app.vault.getAbstractFileByPath(p);
    if (f) {
      await this.app.vault.trash(f, true);
      new import_obsidian.Notice(`\u5DF2\u5220\u9664: ${p}`);
    }
  }
  async showLog(pathArg) {
    var _a;
    const p = (_a = pathArg != null ? pathArg : this.activePath()) != null ? _a : this.cwd();
    const abs = this.abs(p);
    if (this.useTortoise()) {
      return this.gui("log", abs, [`/limit:${this.settings.logLimit}`]);
    }
    const out = await this.try(["log", "-l", String(this.settings.logLimit), "-v", abs]);
    if (out)
      new LogModal(this.app, out).open();
  }
  async showStatus(pathArg) {
    const abs = this.abs(pathArg);
    if (this.useTortoise())
      return this.gui("repostatus", abs);
    const out = await this.try(["status", abs]);
    if (out)
      new LogModal(this.app, out, "SVN \u72B6\u6001").open();
  }
  async cleanup(pathArg) {
    var _a;
    const p = (_a = pathArg != null ? pathArg : this.activePath()) != null ? _a : void 0;
    const abs = this.abs(p);
    if (this.useTortoise()) {
      return this.gui("cleanup", abs, [
        "/cleanup",
        "/breaklocks",
        "/nodlg"
      ]);
    }
    new import_obsidian.Notice("SVN \u6E05\u7406\u4E2D...");
    const out = await this.try(["cleanup", "--break-locks", abs], "SVN \u6E05\u7406\u5B8C\u6210");
    if (out === null)
      await this.try(["cleanup", abs], "SVN \u6E05\u7406\u5B8C\u6210");
  }
  async diff(pathArg) {
    const p = pathArg != null ? pathArg : this.activePath();
    if (!p)
      return new import_obsidian.Notice("\u6CA1\u6709\u76EE\u6807\u6587\u4EF6");
    const abs = this.abs(p);
    if (this.useTortoise())
      return this.gui("diff", abs);
    const out = await this.try(["diff", abs]);
    if (out === null)
      return;
    if (!out.trim())
      return new import_obsidian.Notice("\u65E0\u5DEE\u5F02");
    new LogModal(this.app, out, "SVN \u5DEE\u5F02").open();
  }
  async lock(pathArg) {
    const p = pathArg != null ? pathArg : this.activePath();
    if (!p)
      return new import_obsidian.Notice("\u6CA1\u6709\u76EE\u6807\u6587\u4EF6");
    const abs = this.abs(p);
    if (this.useTortoise())
      return this.gui("lock", abs);
    new LockModal(this, p).open();
  }
  async doLock(message, pathArg) {
    const args = ["lock"];
    if (message)
      args.push("-m", message);
    args.push(this.abs(pathArg));
    return this.try(args, "SVN \u9501\u5B9A\u6210\u529F");
  }
  async unlock(pathArg) {
    const p = pathArg != null ? pathArg : this.activePath();
    if (!p)
      return new import_obsidian.Notice("\u6CA1\u6709\u76EE\u6807\u6587\u4EF6");
    const abs = this.abs(p);
    if (this.useTortoise())
      return this.gui("unlock", abs);
    const out = await this.try(["unlock", abs], void 0, true);
    if (out !== null)
      return new import_obsidian.Notice("SVN \u89E3\u9501\u6210\u529F");
    const forced = await this.try(["unlock", "--force", abs], void 0, true);
    if (forced !== null)
      new import_obsidian.Notice("SVN \u5DF2\u5F3A\u5236\u89E3\u9501\uFF08steal/break\uFF09");
    else
      new import_obsidian.Notice("SVN \u89E3\u9501\u5931\u8D25\uFF08\u6587\u4EF6\u53EF\u80FD\u672A\u88AB\u9501\u5B9A\u6216\u975E\u4F60\u672C\u4EBA\u9501\u5B9A\uFF09");
  }
  requestCommit(pathArg) {
    if (this.useTortoise()) {
      return this.gui("commit", this.abs(pathArg), [
        `/closeonend:${this.settings.closeOnEnd}`
      ]);
    }
    return new CommitModal(this, pathArg).open();
  }
  async commit(message, pathArg) {
    const args = ["commit", "-m", message];
    if (pathArg)
      args.push(this.abs(pathArg));
    return this.try(args, "SVN \u63D0\u4EA4\u6210\u529F");
  }
  async loadSettings() {
    const data = await this.loadData() || {};
    const hadAutoUpdate = "autoUpdate" in data;
    delete data.autoUpdate;
    this.settings = Object.assign({}, DEFAULTS, data);
    if (!data.keepDialog) {
      this.settings.closeOnEnd = 0;
      this.settings.keepDialog = true;
    }
    if (hadAutoUpdate || !data.keepDialog) {
      await this.saveSettings();
    }
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
};
var CommitModal = class extends import_obsidian.Modal {
  constructor(plugin, path) {
    super(plugin.app);
    this.plugin = plugin;
    this.path = path;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h3", {
      text: this.path ? `SVN \u63D0\u4EA4: ${this.path}` : "SVN \u63D0\u4EA4 (\u5168\u90E8\u53D8\u66F4)"
    });
    this.textarea = contentEl.createEl("textarea");
    this.textarea.placeholder = "\u63D0\u4EA4\u8BF4\u660E...";
    this.textarea.style.width = "100%";
    this.textarea.style.height = "110px";
    this.textarea.style.marginTop = "8px";
    let onlyCurrent = !!this.path;
    if (this.path) {
      new import_obsidian.Setting(contentEl).setName("\u4EC5\u63D0\u4EA4\u8BE5\u6587\u4EF6").setDesc("\u53D6\u6D88\u52FE\u9009\u5219\u63D0\u4EA4\u6574\u4E2A\u5DE5\u4F5C\u526F\u672C\u7684\u53D8\u66F4").addToggle(
        (t) => t.setValue(onlyCurrent).onChange((v) => onlyCurrent = v)
      );
    }
    const row = contentEl.createDiv({ cls: "svn-log-toolbar" });
    new import_obsidian.Setting(row).addButton((b) => b.setButtonText("\u53D6\u6D88").onClick(() => this.close())).addButton(
      (b) => b.setButtonText("\u63D0\u4EA4").setCta().onClick(async () => {
        const msg = this.textarea.value.trim();
        if (!msg) {
          new import_obsidian.Notice("\u8BF7\u586B\u5199\u63D0\u4EA4\u8BF4\u660E");
          return;
        }
        const target = onlyCurrent && this.path ? this.path : void 0;
        const out = await this.plugin.commit(msg, target);
        if (out !== null)
          this.close();
      })
    );
    this.textarea.focus();
  }
  onClose() {
    this.contentEl.empty();
  }
};
var LockModal = class extends import_obsidian.Modal {
  constructor(plugin, path) {
    super(plugin.app);
    this.plugin = plugin;
    this.path = path;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h3", { text: `SVN \u9501\u5B9A: ${this.path}` });
    this.textarea = contentEl.createEl("textarea");
    this.textarea.placeholder = "\u9501\u5B9A\u539F\u56E0\uFF08\u53EF\u9009\uFF09...";
    this.textarea.style.width = "100%";
    this.textarea.style.height = "90px";
    this.textarea.style.marginTop = "8px";
    const row = contentEl.createDiv({ cls: "svn-log-toolbar" });
    new import_obsidian.Setting(row).addButton((b) => b.setButtonText("\u53D6\u6D88").onClick(() => this.close())).addButton(
      (b) => b.setButtonText("\u9501\u5B9A").setCta().onClick(async () => {
        const out = await this.plugin.doLock(
          this.textarea.value.trim(),
          this.path
        );
        if (out !== null)
          this.close();
      })
    );
    this.textarea.focus();
  }
  onClose() {
    this.contentEl.empty();
  }
};
var LogModal = class extends import_obsidian.Modal {
  constructor(app, text, title = "SVN \u65E5\u5FD7") {
    super(app);
    this.text = text;
    this.title = title;
  }
  onOpen() {
    const { contentEl } = this;
    contentEl.createEl("h3", { text: this.title });
    const wrap = contentEl.createDiv({ cls: "svn-log-modal" });
    const pre = wrap.createEl("pre");
    pre.setText(this.text);
    const bar = wrap.createDiv({ cls: "svn-log-toolbar" });
    new import_obsidian.ButtonComponent(bar).setButtonText("\u5173\u95ED").onClick(() => this.close());
  }
  onClose() {
    this.contentEl.empty();
  }
};
var SvnSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    containerEl.empty();
    new import_obsidian.Setting(containerEl).setName("\u6267\u884C\u5F15\u64CE").setDesc("TortoiseSVN GUI (TortoiseProc.exe) \u6216 svn \u547D\u4EE4\u884C").addDropdown(
      (d) => d.addOption("tortoise", "TortoiseSVN GUI").addOption("svn", "svn \u547D\u4EE4\u884C").setValue(this.plugin.settings.engine).onChange(async (v) => {
        this.plugin.settings.engine = v;
        await this.plugin.saveSettings();
        this.display();
      })
    );
    if (this.plugin.settings.engine === "tortoise") {
      new import_obsidian.Setting(containerEl).setName("TortoiseProc.exe \u8DEF\u5F84").setDesc("\u901A\u5E38\u4E3A C:\\Program Files\\TortoiseSVN\\bin\\TortoiseProc.exe").addText(
        (t) => t.setPlaceholder(TORTOISE_CANDIDATES[0]).setValue(this.plugin.settings.tortoisePath).onChange(async (v) => {
          this.plugin.settings.tortoisePath = v.trim();
          await this.plugin.saveSettings();
        })
      ).addButton(
        (b) => b.setButtonText("\u81EA\u52A8\u68C0\u6D4B").onClick(async () => {
          const hit = TORTOISE_CANDIDATES.find(import_fs.existsSync);
          this.plugin.settings.tortoisePath = hit != null ? hit : "";
          await this.plugin.saveSettings();
          new import_obsidian.Notice(hit ? `\u5DF2\u627E\u5230: ${hit}` : "\u672A\u627E\u5230 TortoiseProc.exe");
          this.display();
        })
      );
    } else {
      new import_obsidian.Setting(containerEl).setName("svn \u53EF\u6267\u884C\u6587\u4EF6\u8DEF\u5F84").setDesc("\u4F8B\u5982 svn\uFF0C\u6216\u5B8C\u6574\u8DEF\u5F84\uFF08\u9700\u5B89\u88C5 command line client tools\uFF09").addText(
        (t) => t.setPlaceholder("svn").setValue(this.plugin.settings.svnPath).onChange(async (v) => {
          this.plugin.settings.svnPath = v.trim() || "svn";
          await this.plugin.saveSettings();
        })
      );
    }
    new import_obsidian.Setting(containerEl).setName("\u8FDB\u5EA6\u5BF9\u8BDD\u6846\u81EA\u52A8\u5173\u95ED").setDesc("closeonend: 0=\u4E0D\u5173\u95ED 1=\u65E0\u9519\u8BEF\u5173\u95ED 2=\u65E0\u9519\u8BEF\u65E0\u51B2\u7A81\u5173\u95ED 3=\u65E0\u9519\u8BEF\u65E0\u51B2\u7A81\u65E0\u5408\u5E76\u5173\u95ED").addDropdown(
      (d) => d.addOption("0", "0 - \u4E0D\u5173\u95ED").addOption("1", "1 - \u65E0\u9519\u8BEF\u5173\u95ED").addOption("2", "2 - \u65E0\u9519\u8BEF\u65E0\u51B2\u7A81\u5173\u95ED").addOption("3", "3 - \u65E0\u9519\u8BEF\u65E0\u51B2\u7A81\u65E0\u5408\u5E76\u5173\u95ED").setValue(String(this.plugin.settings.closeOnEnd)).onChange(async (v) => {
        this.plugin.settings.closeOnEnd = Number(v);
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("\u65E5\u5FD7\u6761\u6570").setDesc("\u67E5\u770B\u65E5\u5FD7\u65F6\u8FD4\u56DE\u7684\u6700\u5927\u6761\u76EE\u6570").addText(
      (t) => t.setValue(String(this.plugin.settings.logLimit)).onChange(async (v) => {
        const n = parseInt(v, 10);
        this.plugin.settings.logLimit = Number.isFinite(n) && n > 0 ? n : 100;
        await this.plugin.saveSettings();
      })
    );
    new import_obsidian.Setting(containerEl).setName("\u6D4B\u8BD5\u8FDE\u63A5").setDesc("\u9A8C\u8BC1\u5F53\u524D\u5F15\u64CE\u53EF\u6267\u884C\u6587\u4EF6\u662F\u5426\u53EF\u7528").addButton(
      (b) => b.setButtonText("\u6D4B\u8BD5").onClick(async () => {
        if (this.plugin.useTortoise()) {
          const exe = this.plugin.tortoiseExe();
          if ((0, import_fs.existsSync)(exe))
            new import_obsidian.Notice(`TortoiseProc \u53EF\u7528: ${exe}`);
          else
            new import_obsidian.Notice(`\u672A\u627E\u5230: ${exe}\uFF0C\u8BF7\u6307\u5B9A\u8DEF\u5F84\u6216\u81EA\u52A8\u68C0\u6D4B`);
          return;
        }
        try {
          const out = await this.plugin.svn(["--version", "--quiet"]);
          new import_obsidian.Notice(`svn \u53EF\u7528, \u7248\u672C: ${out.trim()}`);
        } catch (e) {
          new import_obsidian.Notice(`svn \u4E0D\u53EF\u7528: ${String(e.message || e).trim()}`);
        }
      })
    );
  }
};
